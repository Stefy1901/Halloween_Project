/*
  HalloweenBox: ESP32 motion-triggered sound controller

  HC-SR501 OUT -> GPIO 27
  HC-SR501 GND -> ESP32 GND

  Sends "MOTION\n" over Bluetooth Classic to the Android app.
  Requires an ESP32 target that supports Bluetooth Classic SPP.
*/
#include "BluetoothSerial.h"

BluetoothSerial SerialBT;

const int PIR_PIN = 27;
const unsigned long TRIGGER_COOLDOWN_MS = 10000; // 10 seconds; change to 3000 for 3 seconds

bool previousMotion = false;
unsigned long lastTrigger = 0;

void setup() {
  Serial.begin(115200);
  pinMode(PIR_PIN, INPUT);

  if (SerialBT.begin("HalloweenBox")) {
    Serial.println("HalloweenBox Bluetooth ready.");
  } else {
    Serial.println("Bluetooth initialization failed.");
  }

  Serial.println("Allow the PIR sensor to warm up, then test motion.");
}

void loop() {
  const bool motionDetected = digitalRead(PIR_PIN) == HIGH;
  const unsigned long now = millis();

  if (motionDetected &&
      !previousMotion &&
      (now - lastTrigger >= TRIGGER_COOLDOWN_MS)) {
    Serial.println("Motion detected!");

    if (SerialBT.hasClient()) {
      // Explicit LF avoids the CRLF produced by println().
      SerialBT.print("MOTION\n");
      Serial.println("Sent MOTION to phone.");
    } else {
      Serial.println("Phone not connected.");
    }

    lastTrigger = now;
  }

  previousMotion = motionDetected;
  delay(50);
}
