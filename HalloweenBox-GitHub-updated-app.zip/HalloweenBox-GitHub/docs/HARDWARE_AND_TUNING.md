# Hardware and PIR tuning

## Wiring

| HC-SR501 | ESP32 |
|---|---|
| VCC | 5V/VIN according to the module requirements |
| GND | GND |
| OUT | GPIO 27 |

Power off before changing wires. Ensure the PIR output voltage is safe for the ESP32 input.

## Reduce unwanted detections

1. Find the two adjustment potentiometers on the HC-SR501.
2. The sensitivity adjustment changes the detection range. On common modules, turning it a little counterclockwise reduces range, but verify the labels on your particular board.
3. Make only a small adjustment at a time and test from different distances.
4. The time-delay adjustment controls how long OUT stays HIGH. It is not the sensitivity control.
5. Let the sensor stabilize after power-up (commonly 30–60 seconds; follow the module's instructions).
6. Avoid pointing the sensor at moving foliage, roads, HVAC vents, or other unwanted movement.

## Cooldown

`TRIGGER_COOLDOWN_MS` in the firmware controls the minimum interval between accepted rising-edge triggers. Increase it to reduce repeat sounds; it does not reduce the PIR's physical detection range.

## DFPlayer Mini

The phone-playback design does not need the DFPlayer. If it is still connected, power down before removing its TX/RX wires.
