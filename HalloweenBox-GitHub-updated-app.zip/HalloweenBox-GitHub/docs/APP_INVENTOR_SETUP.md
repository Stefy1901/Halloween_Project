# MIT App Inventor setup

## Components

- `ListPickerESP32`: select the ESP32 Bluetooth device
- `LabelStatus`: connection status / optional debug output
- `BluetoothClient1`: non-visible Bluetooth Classic client
- `Player1`: non-visible audio Player
- `Clock1`: non-visible Clock
- Optional `ButtonTestSound`: manually test playback

Upload six MP3 assets in Designer → Media. Example filenames: `001.mp3`, `002.mp3`, `003.mp3`, `004.mp3`, `005.mp3`, `006.mp3`. Names in the blocks must match the uploaded assets exactly.

## Properties

- `Clock1.TimerInterval`: `200`
- `Clock1.TimerEnabled`: `true`
- `BluetoothClient1.DelimiterByte`: `10`, set in `Screen1.Initialize`

## Blocks

### `Screen1.Initialize`
- Set `BluetoothClient1.DelimiterByte` to `10`.
- Do not set a fixed `Player1.Source` if selecting a source for each motion event.

### `ListPickerESP32.BeforePicking`
Set `ListPickerESP32.Elements` to `BluetoothClient1.AddressesAndNames`.

### `ListPickerESP32.AfterPicking`
Call `BluetoothClient1.Connect` using `ListPickerESP32.Selection` as the address. If true, set `LabelStatus.Text` to `Connected!`; otherwise set it to `Connection failed`.

### `Clock1.Timer`

Create globals:
- `global receivedMessage` initialized to an empty text value
- `global random` initialized to `0`

Block logic:

```text
when Clock1.Timer
  if BluetoothClient1.IsConnected
    if BluetoothClient1.BytesAvailableToReceive > 0
      set global receivedMessage to BluetoothClient1.ReceiveText(-1)

      if global receivedMessage = "MOTION"
        set global random to random integer from 1 to 6

        if global random = 1
          set Player1.Source to "001.mp3"
        else if global random = 2
          set Player1.Source to "002.mp3"
        else if global random = 3
          set Player1.Source to "003.mp3"
        else if global random = 4
          set Player1.Source to "004.mp3"
        else if global random = 5
          set Player1.Source to "005.mp3"
        else
          set Player1.Source to "006.mp3"

        call Player1.Start
```

Generate the random integer once per `MOTION` message, before the conditional chain. `Player1.Start` must be after the entire source-selection chain.

During debugging, `set LabelStatus.Text to global receivedMessage` can display the incoming message. Remove that block when no longer needed.

### Optional sound test button

```text
when ButtonTestSound.Click
  set Player1.Source to "001.mp3"
  call Player1.Start
```

Pair the Krüger speaker to the phone for audio. The app separately connects to the ESP32 for motion messages.

This repository documents the blocks but does not include an exported `.aia` project or original MP3 files.
